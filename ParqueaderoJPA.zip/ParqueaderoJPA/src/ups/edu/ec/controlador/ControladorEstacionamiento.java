package ups.edu.ec.controlador;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import ups.edu.ec.modelo.Cliente;
import ups.edu.ec.modelo.Estacionamiento;

public class ControladorEstacionamiento extends AbstractControler<Estacionamiento> {

    public DefaultTableModel verClientes() {
        DefaultTableModel tabla = new DefaultTableModel();
        List<Estacionamiento> Estacionamientos;
        Estacionamientos = buscartodo();
        tabla.setRowCount(0);
        tabla.addColumn("Numero");
        tabla.addColumn("Estado");
        for (int i = 0; i < Estacionamientos.size(); i++) {

            tabla.addRow(new Object[]{Estacionamientos.get(i).getNumeroDeEstacionamiento(), Estacionamientos.get(i).getEstado()});
        }
        return tabla;
    }

    public boolean rentarEstacionamient(String nombre,Cliente cliente,int dias) {
        List<Estacionamiento> Estacionamientos;
        Estacionamientos = buscartodo();
        for (Estacionamiento Estacionamiento1 : Estacionamientos) {
            if (Estacionamiento1.getNumeroDeEstacionamiento().equalsIgnoreCase(nombre)) {
                eliminar(Estacionamiento1);
                Estacionamiento1.setEstado("Rentado");
                Estacionamiento1.setDias(dias);
                Estacionamiento1.setCliente(cliente);
                actualizar(Estacionamiento1);
                return true;
            }

        }

        return false;
    }
    
    public Estacionamiento BuscarEstacionamiento(String placa){
        List<Estacionamiento> ListaEstacionamiento=buscartodo();
        for (Estacionamiento estacionamiento : ListaEstacionamiento) {
            if(estacionamiento.getNumeroDeEstacionamiento().equalsIgnoreCase(placa)){
                return estacionamiento;
                
            }
        }
        return null;
    }
}
