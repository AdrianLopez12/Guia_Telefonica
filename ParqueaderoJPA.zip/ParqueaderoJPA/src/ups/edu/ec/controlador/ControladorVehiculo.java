package ups.edu.ec.controlador;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import ups.edu.ec.modelo.Cliente;
import ups.edu.ec.modelo.Estacionamiento;
import ups.edu.ec.modelo.Vehiculo;

public class ControladorVehiculo extends AbstractControler<Vehiculo>{
    Calendar calendario=new GregorianCalendar();
    int hora,minutos;
    public Vehiculo ingresarvehiculo(String placa, Estacionamiento estacionamiento){
        List<Vehiculo> Listavehiculo=buscartodo();
        
        for (Vehiculo vehiculo : Listavehiculo) {
            if(vehiculo.getPlaca().trim().equalsIgnoreCase(placa.trim())){
                eliminar(vehiculo);
                vehiculo.setEstacionamiento(estacionamiento);
                hora=calendario.get(Calendar.HOUR_OF_DAY);
                minutos=calendario.get(Calendar.MINUTE);
                vehiculo.setHora(hora);
                vehiculo.setMinuto(minutos);
                actualizar(vehiculo);
                return vehiculo;
            }
            
            
        }
        return null;
    }
    
    public DefaultTableModel listarVehiculos(Cliente c)
    {
        DefaultTableModel tabla=new DefaultTableModel();
        tabla.addColumn("Numero");
        tabla.addColumn("Placa");
        List<Vehiculo> Listavehiculo=buscartodo();
        for (Vehiculo vehiculo : Listavehiculo) {
        
            if(vehiculo.getCliente().equals(c)){
                
                 tabla.addRow(new Object[]{vehiculo.getEstacionamiento().getNumeroDeEstacionamiento(),vehiculo.getPlaca()    });
                
            }
        }
        return tabla;
    }    
    public float sacarvheiculo(String placa){
        float costo=0;
        List<Vehiculo> Listavehiculo=buscartodo();
        for (Vehiculo vehiculo : Listavehiculo) {
            if(vehiculo.getPlaca().equalsIgnoreCase(placa)){
                eliminar(vehiculo);
                vehiculo.setEstacionamiento(null);
                hora=calendario.get(Calendar.HOUR_OF_DAY);
                minutos=calendario.get(Calendar.MINUTE);
                int h=vehiculo.getHora();
                int m=vehiculo.getMinuto();
                costo=(hora-h);
                int i;
                for (i = 0; minutos > m; i++) {
                    minutos=minutos-15;
                    
                }
                costo=(float) (costo+(0.25*i));
                
            }
        }
        return costo;
        
    }
    
    
}
