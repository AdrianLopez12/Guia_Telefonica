package ups.edu.ec.controlador;

import java.util.List;
import ups.edu.ec.modelo.Cliente;

public class ControladorCliente extends AbstractControler<Cliente>{
   
    public Cliente loguearse(String cedula, String contrasena){
        
        List<Cliente> cli=this.buscartodo();
        for (Cliente cliente : cli) {
            if(cliente.getCedula().equalsIgnoreCase(cedula)&&cliente.getContrasena().equalsIgnoreCase(contrasena)){
                return cliente;
            }
        }
        return null;
    }
    
    public boolean borrarPorCedula(String cedula){
        List<Cliente> cli=this.buscartodo();
        for (Cliente cliente : cli) {
            if(cliente.getCedula().equalsIgnoreCase(cedula)){
                eliminar(cliente);
                return true;
            }
            
        }
        return false;
    }
    public boolean actualizarPorCedula(Cliente client){
        List<Cliente> cli=this.buscartodo();
        for (Cliente cliente : cli) {
            if(client.getCedula().equalsIgnoreCase(cliente.getCedula())){
                eliminar(cliente);
                actualizar(client);
                return true;
            }
        }
        return false;
        
    }
}
