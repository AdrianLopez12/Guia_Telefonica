/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ups.edu.ec.vista;

import ups.edu.ec.controlador.ControladorEspacios;
import ups.edu.ec.controlador.ControladorTicket;
import ups.edu.ec.controlador.ControladorVehiculo;
import ups.edu.ec.modelo.Ticket;
import ups.edu.ec.modelo.Vehiculo;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentanaImprimirTicket extends javax.swing.JInternalFrame {

    private ControladorVehiculo controladorVehiculo;
    private ControladorTicket controladorTicket;
    private ControladorEspacios controladorEspacios;
    DefaultTableModel modelo;
    private String valorPagar;
    private String textoFracciones;
    private String ticketnoEncontrado;
   

    public VentanaImprimirTicket(ControladorVehiculo controladorVehiculo, ControladorTicket controladorTicket, VentanaPrincipal Ventanaprincipal, ControladorEspacios controladorEspacios) {
        initComponents();
        this.controladorTicket = controladorTicket;
        this.controladorTicket.verTicketsVehiculo((DefaultTableModel) jTable1.getModel());
        this.controladorEspacios=controladorEspacios;
        this.controladorVehiculo=controladorVehiculo;
    }



    public void actualizar() {
        this.controladorTicket.verTicketsVehiculo((DefaultTableModel) jTable1.getModel());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jToggleButton1 = new javax.swing.JToggleButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setClosable(true);

        jLabel1.setText("Ingrese codigo de ticket");

        jToggleButton1.setText("Aceptar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "#Ticket", "ingreso"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jToggleButton1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(65, 65, 65))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jToggleButton1)
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(100, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
  
        int codigotick=Integer.parseInt(jTextField1.getText());
  
        Ticket ticket = controladorTicket.buscarTicketPorCodigo(codigotick);
         
        actualizar();
        if (ticket != null) {
            double total = controladorTicket.precio(ticket);
            JOptionPane.showMessageDialog(this, "Valor a pagar" + total);
            double fracciones = total / 0.25;
            JOptionPane.showMessageDialog(this, "y tantas fracciones" + total);
          
            Vehiculo v=controladorVehiculo.buscarVehiculoPorTicket(codigotick);
            System.out.println(v);
            controladorEspacios.actualizar(v.getEspacio(), "Libre");
            jTextField1.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Error");
            jTextField1.setText("");
        }
    }//GEN-LAST:event_jToggleButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
