package ups.edu.ec.vista;

import ups.edu.ec.controladores.EspaciosDAO;
import ups.edu.ec.controladores.TicketDAO;
import ups.edu.ec.controladores.ClienteDAO;
import ups.edu.ec.controladores.VehiculoDAO;
import ups.edu.ec.controlador.ControladorCliente;
import ups.edu.ec.controlador.ControladorEspacios;
import javax.swing.JOptionPane;
import ups.edu.ec.controlador.ControladorTicket;
import ups.edu.ec.controlador.ControladorVehiculo;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.ResourceBundle;


import javax.swing.JMenuItem;

public class VentanaPrincipal extends javax.swing.JFrame {
    
    Calendar calendario;
    //ventanas
    private VentanaRegistrarCliente ventanaRegistrarCliente;
    private VentanaRegistrarVehiculo ventanaRegistrarVehiculo;
    private PantallaRentar pantallaRentar;
    private PantallaLogin pantallaLogin;
    private PantallaEspaciosDisponibles pantallaEspaciosDisponibles;
 
  
    private VentanaImprimirTicket ventanaimprimirTicket;
    private VentanaIngresarVehiculo ventanaIngresarVehiculo;
//controladores
    private ControladorCliente controladorCliente;
    private ControladorVehiculo controladorVehiculo;
    private ControladorTicket controladorTicket;
    private ControladorEspacios controladorEspacios;
//dao
    private ClienteDAO clienteDAO;
    private VehiculoDAO vehiculoDAO;
    private TicketDAO ticketDAO;
    private EspaciosDAO espaciosDAO;
    //internacionalizacion

    public VentanaPrincipal() {
        initComponents();
        
        jMenu2.setVisible(false);
        ingresoMenu.setVisible(false);
        jMenuItem7.setVisible(false);
        
        
        this.setLocationRelativeTo(null);
      
        //instancia DAOS
        clienteDAO = new ClienteDAO();
        vehiculoDAO = new VehiculoDAO();
        ticketDAO = new TicketDAO();
        espaciosDAO=new EspaciosDAO();
        
        //instancia controloadores
        controladorCliente = new ControladorCliente(clienteDAO);
        controladorTicket = new ControladorTicket(ticketDAO, controladorVehiculo);
	controladorVehiculo = new ControladorVehiculo(vehiculoDAO, controladorCliente, controladorTicket);
        controladorEspacios=new ControladorEspacios(espaciosDAO);
	
  registrarEspacio();
        //instancia las vistas
        ventanaRegistrarVehiculo = new VentanaRegistrarVehiculo(controladorCliente, controladorVehiculo);
      
        ventanaRegistrarCliente = new VentanaRegistrarCliente(controladorCliente);
        ventanaimprimirTicket = new VentanaImprimirTicket(controladorVehiculo,controladorTicket, this,controladorEspacios);
        pantallaLogin=new PantallaLogin(controladorCliente, this);
        pantallaRentar=new PantallaRentar(controladorEspacios);
        ventanaIngresarVehiculo=new VentanaIngresarVehiculo(controladorVehiculo, this, controladorEspacios);
        pantallaEspaciosDisponibles=new PantallaEspaciosDisponibles(controladorEspacios);
	ventanaRegistrarCliente.setVentanaPrincipal(this);
	ventanaRegistrarVehiculo.setVentanaPrincipal(this);
        ventanaIngresarVehiculo.setVentanaPrincipal(this);
        
        calendario = new GregorianCalendar();
    
    }
    public void registrarEspacio(){
        for (int i = 1; i <= 20; i++) {
            String nombreEsp="A"+i;
            controladorEspacios.registrar(nombreEsp, "Libre");
        }
        for (int i = 1; i <= 20; i++) {
            String nombreEsp="B"+i;
            controladorEspacios.registrar(nombreEsp, "Libre");
        }
        for (int i = 1; i <= 20; i++) {
            String nombreEsp="C"+i;
            controladorEspacios.registrar(nombreEsp, "Libre");
        }
        
    }
    public VentanaRegistrarVehiculo getVentanaRegistrarVehiculo() {
        return ventanaRegistrarVehiculo;
    }

    public VentanaIngresarVehiculo getVentanaIngresarVehiculo() {
        return ventanaIngresarVehiculo;
    }

    public void setVentanaIngresarVehiculo(VentanaIngresarVehiculo ventanaIngresarVehiculo) {
        this.ventanaIngresarVehiculo = ventanaIngresarVehiculo;
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktopPane = new javax.swing.JDesktopPane();
        menuBar = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        ingresoMenu = new javax.swing.JMenu();
        registrarVehiculoItem = new javax.swing.JMenuItem();
        menuItemIngresoVehiculo = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);

        desktopPane.setBackground(new java.awt.Color(0, 0, 255));
        getContentPane().add(desktopPane, java.awt.BorderLayout.CENTER);

        jMenu1.setText("Login");

        jMenuItem1.setText("Login");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Salir");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        menuBar.add(jMenu1);

        jMenu3.setText("Parqueadero");

        jMenuItem7.setText("Rentar estacionamiento");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem7);

        jMenuItem4.setText("Estacionamientos disponibles");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem4);

        menuBar.add(jMenu3);

        jMenu2.setText("Usuario");

        jMenuItem3.setText("Registrar");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        menuBar.add(jMenu2);

        ingresoMenu.setMnemonic('f');
        ingresoMenu.setText("Vehiculos");

        registrarVehiculoItem.setText("Registar Vehiculo");
        registrarVehiculoItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarVehiculoItemActionPerformed(evt);
            }
        });
        ingresoMenu.add(registrarVehiculoItem);

        menuItemIngresoVehiculo.setText("Ingresar Vehiculo");
        menuItemIngresoVehiculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuItemIngresoVehiculoActionPerformed(evt);
            }
        });
        ingresoMenu.add(menuItemIngresoVehiculo);

        jMenuItem6.setText("Ingrese su ticket");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        ingresoMenu.add(jMenuItem6);

        menuBar.add(ingresoMenu);

        setJMenuBar(menuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void registrarVehiculoItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarVehiculoItemActionPerformed
        desktopPane.add(ventanaRegistrarVehiculo);
        ventanaRegistrarVehiculo.setVisible(true);

    }//GEN-LAST:event_registrarVehiculoItemActionPerformed

    private void menuItemIngresoVehiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuItemIngresoVehiculoActionPerformed
        desktopPane.add(ventanaIngresarVehiculo);
        ventanaIngresarVehiculo.setVisible(true);
        
        
    }//GEN-LAST:event_menuItemIngresoVehiculoActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
      desktopPane.add(ventanaRegistrarCliente);
        ventanaRegistrarCliente.setVisible(true);
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        desktopPane.add(ventanaimprimirTicket);
        ventanaimprimirTicket.setVisible(true);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        jMenu2.setVisible(false);
        jMenuItem7.setVisible(false);
        ingresoMenu.setVisible(false);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        desktopPane.add(pantallaLogin);
        pantallaLogin.setVisible(true);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        desktopPane.add(pantallaRentar);
        pantallaRentar.setVisible(true);
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        desktopPane.add(pantallaEspaciosDisponibles);
        pantallaEspaciosDisponibles.setVisible(true);
        
        
    }//GEN-LAST:event_jMenuItem4ActionPerformed
    public void logueado(){
    jMenu2.setVisible(true);
        ingresoMenu.setVisible(true);
        jMenuItem7.setVisible(true);
}
     public void logueadoUsuario(){
         jMenu2.setVisible(false);
        ingresoMenu.setVisible(true);
        jMenuItem7.setVisible(true);
}
    
    
    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktopPane;
    private javax.swing.JMenu ingresoMenu;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem menuItemIngresoVehiculo;
    private javax.swing.JMenuItem registrarVehiculoItem;
    // End of variables declaration//GEN-END:variables

}
