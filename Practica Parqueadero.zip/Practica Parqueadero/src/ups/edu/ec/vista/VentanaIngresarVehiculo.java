package ups.edu.ec.vista;
import ups.edu.ec.controlador.ControladorVehiculo;
import ups.edu.ec.controlador.ControladorTicket;
import ups.edu.ec.controlador.ControladorEspacios;
import ups.edu.ec.controladores.TicketDAO;
import ups.edu.ec.controladores.VehiculoDAO;
import ups.edu.ec.modelo.Ticket;
import ups.edu.ec.modelo.Vehiculo;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentanaIngresarVehiculo extends javax.swing.JInternalFrame {
    
    private ControladorVehiculo controladorVehiculo;
    private ControladorEspacios controladorEspacios;
     private VentanaPrincipal ventanaPrincipal;
    
    private VehiculoDAO vehiculoDAO;
    
    private TicketDAO ticketDAO;
    private String vehiculonoencontrado;
    private String vehiculoIngresado;
     private ControladorTicket controladorTicket;
     
     public void setVentanaPrincipal(VentanaPrincipal ventanaPrincipal) {
        this.ventanaPrincipal = ventanaPrincipal;
    }
     
    public VentanaIngresarVehiculo(ControladorVehiculo controladorVehiculo, VentanaPrincipal ventanaPrincipal, ControladorEspacios controladorEspacios) {
        initComponents();
       
       jButton1.setEnabled(false);
      this.controladorVehiculo=controladorVehiculo;
      this.controladorEspacios=controladorEspacios;
      
     
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        jLabel1.setText("Ingrese la placa de su vehiculo");

        jButton1.setText("Ingresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel2.setText("Seleccione espacio a usar");

        jToggleButton1.setText("Listar");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(108, 108, 108))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jToggleButton1)
                                .addGap(116, 116, 116))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(32, 32, 32)
                        .addComponent(jButton1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jToggleButton1)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       String placa=jTextField1.getText();
       String nombreEst = (String)jTable1.getValueAt(jTable1.getSelectedRow(), 0);
            String estado = (String)jTable1.getValueAt(jTable1.getSelectedRow(), 1);

        Vehiculo v = controladorVehiculo.BuscarVehiculoPorPlaca(placa, nombreEst);
        
        
        if(v==null){
            JOptionPane.showMessageDialog(this, "No econtrado");
            jTextField1.setText("");
        }else{
            jTextField1.setText("");
            
           
            
            
            if(estado.equalsIgnoreCase("Libre")){
              
                controladorEspacios.actualizar(nombreEst, "Ocupado");
                 controladorEspacios.verClientes((DefaultTableModel)jTable1.getModel());
                 
                 JOptionPane.showMessageDialog(this, "vehivculo ingresado placa: "+v.getPlaca()+" numero de ticket: "+v.getTickete().getNumeroT());
                 v.setEspacio(nombreEst);
                 controladorVehiculo.actualizar(v);
            }else{
                JOptionPane.showMessageDialog(this, "Espacio ocupado");
            }
            
            
        }
        
        jTextField1.setText("");
         
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        if(evt.getClickCount() == 1 && !evt.isConsumed()){
            evt.consume();
            jButton1.setEnabled(true);
        }
        
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        ventanaPrincipal.getVentanaIngresarVehiculo().actualizar();;
        ventanaPrincipal.getVentanaIngresarVehiculo().show();

    }//GEN-LAST:event_formInternalFrameClosed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
         controladorEspacios.verClientes((DefaultTableModel)jTable1.getModel());
    }//GEN-LAST:event_jToggleButton1ActionPerformed

public void actualizar(){
        controladorEspacios.verClientes((DefaultTableModel)jTable1.getModel());
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToggleButton jToggleButton1;
    // End of variables declaration//GEN-END:variables
}
