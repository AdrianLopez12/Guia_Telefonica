package ups.edu.ec.modelo;

import java.util.Objects;


public class Espacios {
    private String nombreEspacio;
    private String estado;

    public String getNombreEspacio() {
        return nombreEspacio;
    }

    public void setNombreEspacio(String nombreEspacio) {
        this.nombreEspacio = nombreEspacio;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Espacios(String nombreEspacio, String estado) {
        this.nombreEspacio = nombreEspacio;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Espacios{" + "nombreEspacio=" + nombreEspacio + ", estado=" + estado + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + Objects.hashCode(this.nombreEspacio);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Espacios other = (Espacios) obj;
        if (!Objects.equals(this.nombreEspacio, other.nombreEspacio)) {
            return false;
        }
        return true;
    }
    
}
