/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ups.edu.ec.modelo;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;


/**
 *
 * @author user
 */
public class Ticket {
    private int numeroT;
    private LocalDateTime FechaIngreso;
    private LocalDateTime FechaSalida;
    private Vehiculo vehiculo;
    private String nombreEspacio;

    public Ticket(int numeroT, String nombreEspacio) {
        this.numeroT = numeroT;
        this.nombreEspacio = nombreEspacio;
    }

    
    
    
    
    public LocalDateTime getFechaIngreso() {
        return FechaIngreso;
    }

    public void setFechaIngreso(LocalDateTime FechaIngreso) {
        this.FechaIngreso = FechaIngreso;
    }

    public LocalDateTime getFechaSalida() {
        return FechaSalida;
    }

    public void setFechaSalida(LocalDateTime FechaSalida) {
        this.FechaSalida = FechaSalida;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public String getNombreEspacio() {
        return nombreEspacio;
    }

    public void setNombreEspacio(String nombreEspacio) {
        this.nombreEspacio = nombreEspacio;
    }
    public int getNumeroT() {
        return numeroT;
    }

    public void setNumeroT(int numeroT) {
        this.numeroT = numeroT;
    }

    @Override
    public String toString() {
        return "Ticket{" + "numeroT=" + numeroT + '}';
    }

 

    
}

