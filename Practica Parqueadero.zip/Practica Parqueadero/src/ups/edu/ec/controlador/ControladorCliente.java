package ups.edu.ec.controlador;

import ups.edu.ec.idao.IClienteDAO;
import ups.edu.ec.modelo.Vehiculo;
import ups.edu.ec.modelo.Cliente;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ControladorCliente {

    //modelo
    //modelo
    private Cliente cliente;

    //daos
    private IClienteDAO clienteDAO;

    public ControladorCliente(IClienteDAO clienteDAO) {
        this.clienteDAO = clienteDAO;

    }

    public void registrar(String cedula, String nombre, String direccion, String telefono, String contrasena) {

        cliente = new Cliente(cedula, nombre, direccion, telefono, contrasena);

        clienteDAO.create(cliente);

    }

    public void actualizar(String cedula, String nombre, String direccion, String telefono) {
        cliente = new Cliente(cedula, nombre, direccion, telefono);
        clienteDAO.update(cliente);
    }

    public void eliminar(String cedula, String nombre, String direccion, String telefono) {
        cliente = new Cliente(cedula, nombre, direccion, telefono);
        clienteDAO.delete(cliente);
    }

    public Cliente verCliente(String cedula) {
        cliente = clienteDAO.read(cedula);
        return cliente;
    }
      public List<Cliente> listarClientes(){
	return clienteDAO.findAll();
    }

    public boolean validarCliente(String cedula) {
        cliente = clienteDAO.login(cedula);
        if (cliente != null) {
            return true;
        } else {
            return false;
        }
    }
        public void verClientes(DefaultTableModel tabla){
        List<Cliente> clientes;
        clientes = clienteDAO.findAll();
        tabla.setRowCount(0);
	    for(int i = 0; i < clientes.size(); i++){
		tabla.addRow(new Object[]{
		    clientes.get(i).getCedula(),
		    clientes.get(i).getNombre(),
		    clientes.get(i).getDireccion(),
		    clientes.get(i).getTelefono()
		});
	    }
    }

    public void agregarVehiculo(Vehiculo vehiculo) {
        cliente.agregarVehiculo(vehiculo);
        clienteDAO.update(cliente);
    }

    public void actualizarVehiculo(Vehiculo vehiculo) {
        cliente.actualizarVehiculo(vehiculo);
    }

    public void eliminarVehiculo(Vehiculo vehiculo) {
        cliente.eliminarVehiculo(vehiculo);
    }
    public Cliente loguearCliente(String nombre, String contrasena){
        List<Cliente> clien=clienteDAO.findAll();
        
        for (Cliente cliente : clien) {
            if(cliente.getCedula().equalsIgnoreCase(nombre)&&cliente.getContrasena().equals(contrasena)){
                return cliente;
            }
                
        }
        return null;
    }
}
