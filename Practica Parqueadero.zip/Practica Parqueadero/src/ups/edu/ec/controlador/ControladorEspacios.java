package ups.edu.ec.controlador;
import ups.edu.ec.idao.IEspacioDAO;
import ups.edu.ec.modelo.Espacios;
import java.util.List;
import javax.swing.table.DefaultTableModel;
       
public class ControladorEspacios {
    IEspacioDAO espacioDAO;

    public ControladorEspacios(IEspacioDAO iEspacioDAO) {
    this.espacioDAO=iEspacioDAO;
    }
    public void registrar(String nombreEspacio, String estado) {

        Espacios e = new Espacios(nombreEspacio, estado);

        espacioDAO.create(e);

    }
   public void verClientes(DefaultTableModel tabla){
        List<Espacios> clientes;
        clientes = espacioDAO.findAll();
        System.out.println(clientes.size());
        tabla.setRowCount(0);
	    for(int i = 0; i < clientes.size(); i++){
           
		tabla.addRow(new Object[]{
                    
		    clientes.get(i).getNombreEspacio(),
		    clientes.get(i).getEstado(),
		   
		});
	    }
    }
     public void actualizar(String nombre, String estado) {
        Espacios e= new Espacios(nombre, estado);
        espacioDAO.update(e);
    }
    
    
    
    
}
