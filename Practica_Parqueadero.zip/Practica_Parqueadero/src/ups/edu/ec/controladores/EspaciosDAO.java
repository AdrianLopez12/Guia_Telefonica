package ups.edu.ec.controladores;

import ups.edu.ec.idao.IClienteDAO;
import ups.edu.ec.idao.IEspacioDAO;
import ups.edu.ec.modelo.Espacios;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class EspaciosDAO implements IEspacioDAO {
    public List<Espacios> espacios;

    public EspaciosDAO() {
        espacios=new ArrayList();
    }
    
    
    @Override
    public void create(Espacios espacios) {
   
        this.espacios.add(espacios);
    }

    @Override
    public Espacios read(String nombreEspacio) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Espacios espacios) {
        for (int i = 0; i < this.espacios.size(); i++) {
            Espacios c = this.espacios.get(i);
            if (c.getNombreEspacio().equalsIgnoreCase(espacios.getNombreEspacio())) {
                System.out.println("ghjk");
                this.espacios.set(i, espacios);
                break;
            }

        }
    }

    @Override
    public void delete(Espacios espacios) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Espacios> findAll() {
        return espacios;
    }

   
}

    
