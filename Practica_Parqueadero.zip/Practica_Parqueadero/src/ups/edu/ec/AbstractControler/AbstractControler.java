package ups.edu.ec.AbstractControler;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractControler<E> {
    
    public List<E> lista;
    public AbstractControler(){
        lista=new ArrayList();
    }
    public boolean create(E objeto)
    {
        
        return lista.add(objeto);
    }    
    public E read(E comparacion){
        return lista.stream().filter(objeto->objeto.equals(comparacion)).findFirst().get();
    }
    public boolean delete(E objeto){
        E objetoEliminar=read(objeto);
        return (objetoEliminar!=null)? lista.remove(objetoEliminar):false;
    }
    public int BuscarPocicion(E comparacion){
        
        for (int i = 0; i < lista.size(); i++) {
           E objeto=lista.get(i);
         
           if(objeto.equals(comparacion)){
               return i;
           }
           
        }
    return -1;
    }
    
    public boolean update(E objeto){
         int index=BuscarPocicion(objeto);
        System.out.println(index);
         if(index>=0){
         lista.set(index, objeto);     
        
         }
         
         return (index>=0);
    }
    public List<E> findAll(){
        return lista;
    }
    public void setLista(List<E> lista){
        this.lista=lista;
    }
    
  
    public abstract boolean validarObjeto(E objeto);
    
}
