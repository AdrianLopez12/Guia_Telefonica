package ups.edu.ec.idao;

import java.util.List;
import ups.edu.ec.modelo.Espacios;

public interface IEspacioDAO {

    public void create(Espacios espacios);

    public Espacios read(String nombreEspacio);

    public void update(Espacios espacios);

    public void delete(Espacios espacios);

    public List<Espacios> findAll();


}
