package ups.edu.ec.idao;

import ups.edu.ec.modelo.Ticket;
import java.util.List;

public interface ITicketDAO {
 public void create(Ticket ticket);

    public Ticket read(String cedula);

    public void update(Ticket ticket);

    public void delete(Ticket ticket);

    public List<Ticket> findAll();   

}
