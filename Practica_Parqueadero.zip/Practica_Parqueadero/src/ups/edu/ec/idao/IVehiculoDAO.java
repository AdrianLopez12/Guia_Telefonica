package ups.edu.ec.idao;

import ups.edu.ec.modelo.Vehiculo;
import java.util.List;

public interface IVehiculoDAO {
      public void create(Vehiculo vehiculo);

    public Vehiculo read(String placa);

    public void update(Vehiculo vehiculo);

    public void delete(Vehiculo vehiculo);

    public List<Vehiculo> findAll();
}
